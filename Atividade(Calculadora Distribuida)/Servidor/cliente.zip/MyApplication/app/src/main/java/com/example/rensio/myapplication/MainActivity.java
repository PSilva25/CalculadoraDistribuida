package com.example.rensio.myapplication;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilePermission;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Button button1;
    private Button button2;
    private Button button3;
    private Button button4;
    private Button button5;
    private Button button6;
    private Button button7;
    private Button button8;
    private Button button9;
    private Button button0;
    private Button buttonponto;
    private Button buttonsoma;
    private Button buttonmult;
    private Button buttondiv;
    private Button buttonsub;
    private Button buttonresultado;
    private TextView info;

    int contamais=0, contamenos=0, contamult=0,contadiv=0;

    EditText e1, e2;
    TextView mostra;

    String mensagemS = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        Thread x = new Thread(new MyServer());

        x.start();

        botoes();

        button0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                info.setText(info.getText().toString() + "0");
            }
        });


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                info.setText(info.getText().toString() + "1");
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                info.setText(info.getText().toString() + "2");
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                info.setText(info.getText().toString() + "3");
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                info.setText(info.getText().toString() + "4");
            }
        });
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                info.setText(info.getText().toString() + "5");
            }
        });
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                info.setText(info.getText().toString() + "6");
            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                info.setText(info.getText().toString() + "7");
            }
        });
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                info.setText(info.getText().toString() + "8");
            }
        });
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                info.setText(info.getText().toString() + "9");
            }
        });

        buttonsoma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                info.setText(info.getText().toString() + " + ");
                contamais = contamais+1;
            }
        });

        buttonmult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                info.setText(info.getText().toString() + " x ");
                contamult = contamult +1;
            }
        });
        buttonsub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                info.setText(info.getText().toString() + " - ");

                contamenos = contamenos +1;

            }
        });
        buttondiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                info.setText(info.getText().toString() + " / ");

                contadiv = contadiv + 1;
            }
        });
        buttonponto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                info.setText(info.getText().toString() + ".");
            }
        });


    }
    private void botoes(){

        button0 = (Button)findViewById(R.id.btnzero);
        button1 = (Button)findViewById(R.id.btn1);
        button2 = (Button)findViewById(R.id.btn2);
        button3 = (Button)findViewById(R.id.btn3);
        button4 = (Button)findViewById(R.id.btn4);
        button5 = (Button)findViewById(R.id.btn5);
        button6 = (Button)findViewById(R.id.btn6);
        button7 = (Button)findViewById(R.id.btn7);
        button8 = (Button)findViewById(R.id.btn8);
        button9 = (Button)findViewById(R.id.btn9);
        buttonponto = (Button)findViewById(R.id.btnponto);
        buttonsoma = (Button)findViewById(R.id.btnmais);
        buttonsub = (Button)findViewById(R.id.btnmenos);
        buttonmult = (Button)findViewById(R.id.btnmult);
        buttondiv = (Button)findViewById(R.id.btndiv);
        buttonresultado = (Button)findViewById(R.id.btnigual);
        info = (TextView) findViewById(R.id.info);




    }

    class MyServer implements Runnable {

        ServerSocket sct;
        Socket mysocket;

        DataInputStream dis;
        BufferedReader br;

        Handler hd = new Handler();


        @Override
        public void run() {


            try {
                sct = new ServerSocket(5001);

                while (true) {

                    mysocket = sct.accept();

                    dis = new DataInputStream(mysocket.getInputStream());
                    mensagemS = dis.readUTF();

                    hd.post(new Runnable() {
                        @Override
                        public void run() {

                            Toast.makeText(getApplicationContext(), "MENSAGEM RECEBIDA DO CLIENTE" + mensagemS, Toast.LENGTH_SHORT).show();

                            info.setText(mensagemS);

                        }
                    });


                }


            } catch (IOException e) {

                e.printStackTrace();
            }


        }


    }


    public void Enviar(View v) {


        if(contamais > 0) {

            Backgroundtask z = new Backgroundtask();

            z.execute("192.168.0.102", info.getText().toString()+" , +");

            Toast.makeText(getApplicationContext(), "MENSAGEM enviada DO CLIENTE" + mensagemS, Toast.LENGTH_SHORT).show();
        }

        if(contamenos > 0) {

            Backgroundtask z = new Backgroundtask();

            z.execute("192.168.0.102", info.getText().toString()+" , -");

            Toast.makeText(getApplicationContext(), "MENSAGEM enviada DO CLIENTE" + mensagemS, Toast.LENGTH_SHORT).show();
        }

        if(contamult > 0) {

            Backgroundtask z = new Backgroundtask();

            z.execute("192.168.0.102", info.getText().toString()+" - x");

            Toast.makeText(getApplicationContext(), "MENSAGEM enviada DO CLIENTE" + mensagemS, Toast.LENGTH_SHORT).show();
        }

        if(contadiv > 0) {

            Backgroundtask z = new Backgroundtask();

            z.execute("192.168.0.102", info.getText().toString()+" - /");

            Toast.makeText(getApplicationContext(), "MENSAGEM enviada DO CLIENTE" + mensagemS, Toast.LENGTH_SHORT).show();
        }



    }


    class  Backgroundtask extends AsyncTask<String, Void, String>{


        Socket socket;
        DataOutputStream dto;
        String ip,mensagem;

        @Override
        protected String doInBackground(String... params) {


            ip = params[0];
            mensagem = params[1];



            try {

                socket = new Socket(ip, 5001);
                dto = new DataOutputStream(socket.getOutputStream());
                dto.writeUTF(mensagem);
                dto.close();
                socket.close();


            } catch (IOException e) {

                e.printStackTrace();
            }

            return null;
        }
    }


}
