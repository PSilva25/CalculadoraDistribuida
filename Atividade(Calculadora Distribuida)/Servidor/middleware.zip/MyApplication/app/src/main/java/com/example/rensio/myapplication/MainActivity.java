package com.example.rensio.myapplication;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilePermission;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText e1, e2;
    TextView mostra,mostra1,mostra2;

    String mensagemS = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        mostra1 = (TextView) findViewById(R.id.textView2);
        mostra2 = (TextView) findViewById(R.id.textView3);

        Thread x = new Thread(new MyServer());

        x.start();

    }


    class MyServer implements Runnable {

        ServerSocket sct;
        Socket mysocket;

        InputStreamReader dis;
        BufferedReader br;

        Handler hd = new Handler();


        @Override
        public void run() {


            try {
                sct = new ServerSocket(5001);

                while (true) {

                    mysocket = sct.accept();

                    dis = new InputStreamReader(mysocket.getInputStream());
                    br = new BufferedReader(dis);
                    mensagemS = br.readLine();

                    hd.post(new Runnable() {
                        @Override
                        public void run() {

                            Toast.makeText(getApplicationContext(), "MENSAGEM RECEBIDA DO CLIENTE" + mensagemS, Toast.LENGTH_SHORT).show();

                            String[] operador = mensagemS.split("\\,");

                            String op = operador[1].trim();




                            if(op.equals("+")){

                                mostra1.setText(operador[0]);
                                mostra2.setText("Encaminhado para servidor de soma");


                                Backgroundtask z = new Backgroundtask();

                                z.execute("192.168.0.101", operador[0]);


                            }

                            if(op.equals("x")){

                                mostra1.setText(operador[0]);
                                mostra2.setText("Encaminhado para servidor de multiplicacao");

                                Backgroundtask2 z = new Backgroundtask2();

                                z.execute("192.168.0.106", operador[0]);

                            }

                            if(op.equals("=")){

                                mostra1.setText(operador[0]);
                                mostra2.setText("Encaminhado para servidor de multiplicacao");

                                Backgroundtask2 z = new Backgroundtask2();

                                z.execute("192.168.0.100", operador[0]);

                            }

                        }
                    });


                }


            } catch (IOException e) {

                e.printStackTrace();
            }


        }


    }


    public void Enviar(View v) {



        Toast.makeText(getApplicationContext(), "MENSAGEM enviada DO CLIENTE" + mensagemS, Toast.LENGTH_SHORT).show();

    }


    class  Backgroundtask extends AsyncTask<String, Void, String>{


        Socket socket;
        DataOutputStream dto;
        String ip,mensagem;

        @Override
        protected String doInBackground(String... params) {


            ip = params[0];
            mensagem = params[1];


            try {

                socket = new Socket(ip, 5001);
                dto = new DataOutputStream(socket.getOutputStream());
                dto.writeUTF(mensagem.trim());
                dto.close();
                socket.close();


            } catch (IOException e) {

                e.printStackTrace();
            }

            return null;
        }
    }






    class  Backgroundtask2 extends AsyncTask<String, Void, String>{


        Socket socket;
        DataOutputStream dto;
        String ip,mensagem;

        @Override
        protected String doInBackground(String... params) {


            ip = params[0];
            mensagem = params[1];


            try {

                socket = new Socket(ip, 5001);
                dto = new DataOutputStream(socket.getOutputStream());
                dto.writeUTF(mensagem.trim());
                dto.close();
                socket.close();


            } catch (IOException e) {

                e.printStackTrace();
            }

            return null;
        }
    }


}
